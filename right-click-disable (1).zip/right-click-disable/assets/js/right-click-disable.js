/**
 * Right Click Disable - frontend script.
 * Blocks the context menu and shows a temporary notification
 * next to the spot where the visitor right-clicked.
 */
( function () {
	'use strict';

	var DESIGNS = [ 'dark', 'light', 'green', 'red', 'blue' ];
	var DEFAULT_MESSAGE = 'Right click is disabled!';
	var DURATION = 2500; // Milliseconds the notification stays visible.
	var GAP = 14; // Space between the cursor and the notification.
	var EDGE = 8; // Minimum space kept from the screen edges.
	var toast = null;
	var hideTimer = null;

	// Read the saved settings from the footer element each time (see rcd_print_config in PHP).
	function getSettings() {
		var config = document.getElementById( 'rcd-config' );
		var message = config ? config.getAttribute( 'data-message' ) : '';
		var design = config ? config.getAttribute( 'data-design' ) : '';

		return {
			message: message || DEFAULT_MESSAGE,
			design: DESIGNS.indexOf( design ) !== -1 ? design : 'dark'
		};
	}

	function getToast() {
		if ( toast ) {
			return toast;
		}

		toast = document.createElement( 'div' );
		toast.setAttribute( 'role', 'status' );
		toast.setAttribute( 'aria-live', 'polite' );
		document.body.appendChild( toast );

		return toast;
	}

	function showToast( x, y ) {
		var settings = getSettings();
		var el = getToast();
		var viewWidth = document.documentElement.clientWidth || window.innerWidth;
		var viewHeight = document.documentElement.clientHeight || window.innerHeight;
		var width;
		var height;
		var left;
		var top;

		window.clearTimeout( hideTimer );

		// Apply the current message and design. textContent keeps the message safe from HTML.
		el.className = 'rcd-toast rcd-toast--' + settings.design;
		el.textContent = settings.message;

		// Measure the notification (offset sizes ignore the scale animation), then place it above the click point.
		el.style.left = '0px';
		el.style.top = '0px';
		width = el.offsetWidth;
		height = el.offsetHeight;

		left = x - width / 2;
		left = Math.max( EDGE, Math.min( left, viewWidth - width - EDGE ) );

		top = y - height - GAP;
		if ( top < EDGE ) {
			top = y + GAP; // Not enough room above, so show it below the cursor.
		}
		top = Math.max( EDGE, Math.min( top, viewHeight - height - EDGE ) );

		el.style.left = left + 'px';
		el.style.top = top + 'px';

		// Force a reflow so the fade-in also runs on the very first click.
		void el.offsetWidth;
		el.classList.add( 'is-visible' );

		hideTimer = window.setTimeout( function () {
			el.classList.remove( 'is-visible' );
		}, DURATION );
	}

	document.addEventListener( 'contextmenu', function ( event ) {
		var x = event.clientX;
		var y = event.clientY;

		event.preventDefault();

		// Keyboard-opened menus can report 0,0. Use the screen center instead.
		if ( ! x && ! y ) {
			x = ( document.documentElement.clientWidth || window.innerWidth ) / 2;
			y = ( document.documentElement.clientHeight || window.innerHeight ) / 2;
		}

		showToast( x, y );
	} );
}() );
